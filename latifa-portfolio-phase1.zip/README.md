# Latifa Portfolio Phase 1

Upload all files to a GitHub repository.

Repository name:
username.github.io

Then enable GitHub Pages.

Replace every ### placeholder with your content.
Replace avatar with your own sprite later.
