
document.getElementById('startBtn').addEventListener('click',()=>{
document.getElementById('landing').classList.add('hidden');
document.getElementById('world').classList.remove('hidden');
});

document.getElementById('musicBtn').addEventListener('click',()=>{
alert('Add your music file later and connect it here.');
});
